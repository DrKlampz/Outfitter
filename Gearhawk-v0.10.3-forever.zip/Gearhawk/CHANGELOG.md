# Gearhawk

## [v0.10.3](https://github.com/DrKlampz/Outfitter/tree/v0.10.3) (2026-11-15)
[Full Changelog](https://github.com/DrKlampz/Outfitter/compare/v0.10.2...v0.10.3) [Previous Releases](https://github.com/DrKlampz/Outfitter/releases)

- v0.10.3: hide dungeons the other faction can't reach  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
