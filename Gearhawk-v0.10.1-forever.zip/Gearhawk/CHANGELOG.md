# Gearhawk

## [v0.10.1](https://github.com/DrKlampz/Outfitter/tree/v0.10.1) (2026-11-11)
[Full Changelog](https://github.com/DrKlampz/Outfitter/compare/v0.10.0...v0.10.1) [Previous Releases](https://github.com/DrKlampz/Outfitter/releases)

- Gearhawk: measure upgrade percent against a typical worn item  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
