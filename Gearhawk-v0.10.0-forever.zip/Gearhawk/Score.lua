local _, ns = ...

-- Reads an item's tooltip and turns it into numbers. English client text.
local scan = CreateFrame("GameTooltip", "GearhawkScanTip", nil, "GameTooltipTemplate")
scan:SetOwner(UIParent, "ANCHOR_NONE")

-- API wrappers: the client may have the old global functions, the C_ ones, or both.
local function Instant(link)
    local f = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if f then
        local ok, a1, a2, a3, a4, a5 = pcall(f, link)
        if ok then return a1, a2, a3, a4, a5 end
    end
end
function ns.EquipLoc(link)
    if not link then return nil end
    local _, _, _, loc = Instant(link)
    if loc and loc ~= "" then return loc end
    local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if f then return select(9, f(link)) end
end
function ns.ItemIcon(link)
    if not link then return nil end
    local _, _, _, _, icon = Instant(link)
    if icon then return icon end
    if GetItemIcon then return GetItemIcon(link) end
end
-- every bag slot as { bag, slot, link }
function ns.BagItems()
    local out = {}
    local C = _G.C_Container
    for bag = 0, 4 do
        local n = (C and C.GetContainerNumSlots and C.GetContainerNumSlots(bag)) or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
        for slot = 1, n do
            local link
            if C and C.GetContainerItemLink then link = C.GetContainerItemLink(bag, slot) end
            if not link and C and C.GetContainerItemInfo then
                local i = C.GetContainerItemInfo(bag, slot)
                link = type(i) == "table" and i.hyperlink or nil
            end
            if not link and GetContainerItemLink then link = GetContainerItemLink(bag, slot) end
            if not link and GetContainerItemInfo then
                local _, _, _, _, _, _, l = GetContainerItemInfo(bag, slot)
                link = l
            end
            if link then out[#out + 1] = { bag = bag, slot = slot, link = link } end
        end
    end
    return out
end

local PRIMARY = { Strength = "STR", Agility = "AGI", Stamina = "STA", Intellect = "INT", Spirit = "SPI" }

local function Add(t, k, v) t[k] = (t[k] or 0) + v end

local function ParseLine(t, text)
    -- the game already adds enchants and gems into the item's stat lines (the "Enchanted: ..." line
    -- only describes them), so counting them again would double the value
    if text:match("^Enchanted: ") or text:match("^Socket Bonus: ") then return end
    -- plain suffix/enchant forms
    do
        local n3, sch = text:match("^%+(%d+) (%a+) Spell Damage$")
        if n3 and sch ~= "Healing" then Add(t, "SP_" .. sch:upper(), tonumber(n3)) return end
        n3 = text:match("^%+(%d+) Spell Damage$") or text:match("^%+(%d+) Spell Power$")
        if n3 then Add(t, "SP", tonumber(n3)) Add(t, "HEAL", tonumber(n3)) return end
        n3, sch = text:match("^%+(%d+) (%a+) Damage$")
        if n3 and (sch == "Fire" or sch == "Frost" or sch == "Shadow" or sch == "Nature" or sch == "Arcane" or sch == "Holy") then
            Add(t, "SP_" .. sch:upper(), tonumber(n3)) return
        end
        n3 = text:match("^%+(%d+) Healing Spells$") or text:match("^%+(%d+) Healing$")
        if n3 then Add(t, "HEAL", tonumber(n3)) return end
        n3 = text:match("^%+(%d+) Damage and Healing Spells$")
        if n3 then Add(t, "SP", tonumber(n3)) Add(t, "HEAL", tonumber(n3)) return end
        n3 = text:match("^%+(%d+) [Mm]ana every 5 sec") or text:match("^Mana Regen %+(%d+)")
        if n3 then Add(t, "MP5", tonumber(n3)) return end
        n3 = text:match("^%+(%d+) Attack Power$")
        if n3 then Add(t, "AP", tonumber(n3)) return end
    end
    -- "+8 Strength"
    local n, stat = text:match("^%+(%d+) (%a+)$")
    if n and PRIMARY[stat] then Add(t, PRIMARY[stat], tonumber(n)) return end
    -- "+4 All Stats" style bonuses
    n = text:match("^%+(%d+) All Stats$")
    if n then for _, k in pairs(PRIMARY) do Add(t, k, tonumber(n)) end return end
    n = text:match("^(%d+) Armor")
    if n then Add(t, "ARMOR", tonumber(n)) return end
    n = text:match("^(%d+) Block$")
    if n then Add(t, "BLOCKVAL", tonumber(n)) return end
    n = text:match("%(([%d%.]+) damage per second%)")
    if n then Add(t, "DPS", tonumber(n)) return end
    local body = text:match("^Equip: (.+)$")
    if not body then return end
    local v
    -- conditional bonuses ("... when fighting Undead") are not part of normal play
    if body:find("when fighting") or body:find("against ") then return end
    local hv, dv = body:match("Increases healing done by up to (%d+) and damage done by up to (%d+) for all magical spells")
    if hv then Add(t, "HEAL", tonumber(hv)) Add(t, "SP", tonumber(dv)) return end
    v = body:match("Increases attack power by (%d+)") or body:match("^%+(%d+) Attack Power")
    if v then Add(t, "AP", tonumber(v)) return end
    v = body:match("Increases ranged attack power by (%d+)")
    if v then Add(t, "RAP", tonumber(v)) return end
    v = body:match("%+(%d+) ranged Attack Power")
    if v then Add(t, "RAP", tonumber(v)) return end
    v = body:match("Increases damage and healing done by magical spells and effects by up to (%d+)")
    if v then Add(t, "SP", tonumber(v)) Add(t, "HEAL", tonumber(v)) return end
    v = body:match("Increases healing done by spells and effects by up to (%d+)")
    if v then Add(t, "HEAL", tonumber(v)) return end
    local school
    school, v = body:match("Increases damage done by (%a+) spells and effects by up to (%d+)")
    if v then Add(t, "SP_" .. school:upper(), tonumber(v)) return end   -- one school only: worth what your spec casts from it
    v = body:match("Allows (%d+)%% of your [Mm]ana regeneration to continue while casting")
    if v then Add(t, "CASTREGEN", tonumber(v)) return end
    v = body:match("Increases your spell damage by up to (%d+)") or body:match("Increases spell power by (%d+)")
    if v then Add(t, "SP", tonumber(v)) Add(t, "HEAL", tonumber(v)) return end
    v = body:match("Restores (%d+) [Mm]ana per 5 sec")
    if v then Add(t, "MP5", tonumber(v)) return end
    v = body:match("Improves your chance to get a critical strike by (%d+)%%")
    if v then Add(t, "CRIT", tonumber(v)) return end
    v = body:match("Improves your chance to hit by (%d+)%%")
    if v then Add(t, "HIT", tonumber(v)) return end
    v = body:match("Improves your chance to hit with spells by (%d+)%%")
    if v then Add(t, "SPHIT", tonumber(v)) return end
    v = body:match("Improves your chance to get a critical strike with spells by (%d+)%%")
    if v then Add(t, "SPCRIT", tonumber(v)) return end
    v = body:match("Increased Defense %+(%d+)")
    if v then Add(t, "DEF", tonumber(v)) return end
    v = body:match("Improves your chance to dodge an attack by (%d+)%%")
    if v then Add(t, "DODGE", tonumber(v)) return end
    v = body:match("Improves your chance to parry an attack by (%d+)%%")
    if v then Add(t, "PARRY", tonumber(v)) return end
    v = body:match("Improves your chance to block attacks with a shield by (%d+)%%")
    if v then Add(t, "BLOCK", tonumber(v)) return end
    v = body:match("Increases the block value of your shield by (%d+)")
    if v then Add(t, "BLOCKVAL", tonumber(v)) return end
end

local function IsRed(r, g, b) return r and r > 0.9 and g < 0.2 and b < 0.2 end

-- Returns { stats = {...}, unusable = text or nil, reqLevel = n or nil } for an item link.
-- Does the player have this profession / skill at that rank? nil when the client can't tell.
local function HasSkill(name, need)
    local n = _G.GetNumSkillLines and GetNumSkillLines()
    if not n or not _G.GetSkillLineInfo then return nil end
    for i = 1, n do
        local sname, header, _, rank = GetSkillLineInfo(i)
        if not header and sname and sname:lower() == name:lower() then
            return (rank or 0) >= need
        end
    end
    return false
end

-- Weapon skills you must have learned (trainer) before a weapon is any use.
local SKILL_OF = { Sword = "Swords", Dagger = "Daggers", Staff = "Staves", Mace = "Maces", Axe = "Axes", Polearm = "Polearms",
    Bow = "Bows", Crossbow = "Crossbows", Gun = "Guns", Wand = "Wands", Thrown = "Thrown", ["Fist Weapon"] = "Fist Weapons" }
local TWO_H = { Sword = "Two-Handed Swords", Axe = "Two-Handed Axes", Mace = "Two-Handed Maces" }
local ALL_WEAPON_SKILLS = {}
for _, v in pairs(SKILL_OF) do ALL_WEAPON_SKILLS[v:lower()] = true end
for _, v in pairs(TWO_H) do ALL_WEAPON_SKILLS[v:lower()] = true end
-- returns the skill name when the character has other weapon skills but not this one (so it must be trained), else nil
local function UntrainedWeapon(rt, twoHand)
    local skill = (twoHand and TWO_H[rt]) or SKILL_OF[rt]
    if not skill or not _G.GetNumSkillLines or not _G.GetSkillLineInfo then return nil end
    local any, has = false, false
    for i = 1, GetNumSkillLines() or 0 do
        local sname, header = GetSkillLineInfo(i)
        if not header and sname then
            local l = sname:lower()
            if ALL_WEAPON_SKILLS[l] then any = true end
            if l == skill:lower() then has = true end
        end
    end
    if any and not has then return skill end
end

-- Armor types by class: the highest the class can wear from this level on.
local ARMOR_FROM = {
    MAGE = { Cloth = 1 }, WARLOCK = { Cloth = 1 }, PRIEST = { Cloth = 1 },
    ROGUE = { Cloth = 1, Leather = 1 }, DRUID = { Cloth = 1, Leather = 1 },
    HUNTER = { Cloth = 1, Leather = 1, Mail = 40 }, SHAMAN = { Cloth = 1, Leather = 1, Mail = 40, Shield = 1 },
    WARRIOR = { Cloth = 1, Leather = 1, Mail = 1, Plate = 40, Shield = 1 },
    PALADIN = { Cloth = 1, Leather = 1, Mail = 1, Plate = 40, Shield = 1 },
}

-- Weapon types each class can use at all (training aside).
local function set(...) local t = {} for _, v in ipairs({ ... }) do t[v] = true end return t end
local WEAPON_TYPES = set("Axe", "Mace", "Sword", "Dagger", "Fist Weapon", "Polearm", "Staff", "Bow", "Crossbow", "Gun", "Wand", "Thrown")
local WEAPONS = {
    WARRIOR = set("Axe", "Mace", "Sword", "Dagger", "Fist Weapon", "Polearm", "Staff", "Bow", "Crossbow", "Gun", "Thrown"),
    PALADIN = set("Axe", "Mace", "Sword", "Polearm"),
    HUNTER = set("Axe", "Dagger", "Fist Weapon", "Polearm", "Staff", "Sword", "Bow", "Crossbow", "Gun", "Thrown"),
    ROGUE = set("Dagger", "Fist Weapon", "Mace", "Sword", "Bow", "Crossbow", "Gun", "Thrown"),
    PRIEST = set("Dagger", "Mace", "Staff", "Wand"),
    SHAMAN = set("Axe", "Dagger", "Fist Weapon", "Mace", "Staff"),
    MAGE = set("Dagger", "Staff", "Sword", "Wand"),
    WARLOCK = set("Dagger", "Staff", "Sword", "Wand"),
    DRUID = set("Dagger", "Fist Weapon", "Mace", "Polearm", "Staff"),
}

-- Two-handed weapons by class (a class that has none of that kind can't use it, whatever the skill list says)
local TWO_H_CLASSES = {
    Sword = set("WARRIOR", "PALADIN", "HUNTER"),
    Axe = set("WARRIOR", "PALADIN", "HUNTER", "SHAMAN"),
    Mace = set("WARRIOR", "PALADIN", "SHAMAN", "DRUID"),
}
-- Relics: each class's own kind only
local RELIC_CLASS = { Libram = "PALADIN", Idol = "DRUID", Totem = "SHAMAN" }

-- A requirement line, whatever colour the tooltip painted it. Returns "level", n | "unusable", text | nil
local function ReadRequirement(text)
    local lvl = text:match("^Requires [Ll]evel (%d+)")
    if lvl then return "level", tonumber(lvl) end
    local skill, rank = text:match("^Requires (.-) %((%d+)%)$")
    if skill then
        local has = HasSkill(skill, tonumber(rank))
        if has == false then return "unusable", text end
        return nil
    end
    local classes = text:match("^Classes: (.+)$")
    if classes then
        local _, cls = UnitClass("player")
        local mine = (UnitClass("player") or ""):lower()
        if not classes:lower():find(mine, 1, true) then return "unusable", text end
        return nil
    end
    if text:match("^Requires ") and not text:find("^Requires [Ll]evel") then
        -- reputation, riding, honor rank and the like: only trust the tooltip's own red
        return "maybe", text
    end
end

function ns.ReadItem(link)
    if not link then return nil end
    local c = ns.cache and ns.cache[link]
    if c then return c end
    scan:ClearLines()
    scan:SetOwner(UIParent, "ANCHOR_NONE")
    scan:SetHyperlink(link)
    if scan:NumLines() < 2 then return nil end        -- item data not loaded yet; try again later
    local res = { stats = {} }
    local _, class = UnitClass("player")
    for i = 2, scan:NumLines() do
        local left = _G["GearhawkScanTipTextLeft" .. i]
        local text = left and left:GetText()
        if text and text ~= "" then
            local r, g, b = left:GetTextColor()
            local red = IsRed(r, g, b)
            local kind, v = ReadRequirement(text)
            if text == "Binds when picked up" then res.bind = "bop"
            elseif text == "Soulbound" then res.bind = "bop"
            elseif text == "Binds to account" or text == "Binds to Blizzard account" then res.bind = res.bind or "account"
            elseif text == "Binds when equipped" then res.bind = res.bind or "boe" end
            local setN, setBody = text:match("^%((%d+)%) Set: (.+)$")
            local setHead, setHave = text:match("^(.-) %((%d+)/%d+%)$")
            if setN then
                -- set bonuses are kept apart: they only matter when this piece is swapped out
                res.setBonus = res.setBonus or {}
                local bt = {}
                setBody = setBody:gsub("%.$", "")
                ParseLine(bt, setBody:match("^[%+%d]") and setBody or ("Equip: " .. setBody))
                res.setBonus[tonumber(setN)] = bt
            elseif setHead and not text:match("^%(") then
                res.setName, res.setCount = setHead, tonumber(setHave)
            elseif kind == "level" then
                res.reqLevel = v
            elseif kind == "unusable" then
                res.unusable = res.unusable or v
            elseif kind == "maybe" then
                if red then res.unusable = res.unusable or v end
            elseif red then
                res.unusable = res.unusable or text
            else
                local before = 0
                for _ in pairs(res.stats) do before = before + 1 end
                local sum0 = 0
                for _, x in pairs(res.stats) do sum0 = sum0 + x end
                ParseLine(res.stats, text)
                local sum1 = 0
                for _, x in pairs(res.stats) do sum1 = sum1 + x end
                if sum1 == sum0 and (text:match("^Equip:") or text:match("^%+%d")) then
                    res.unparsed = res.unparsed or {}
                    res.unparsed[#res.unparsed + 1] = text
                end
            end
            local right = _G["GearhawkScanTipTextRight" .. i]
            local rt = right and right:GetText()
            if rt and rt ~= "" then
                local rr, rg, rb = right:GetTextColor()
                if IsRed(rr, rg, rb) and not rt:find("Requires") then res.unusable = res.unusable or rt end
                if rt == "Wand" then res.isWand = true end
                if RELIC_CLASS[rt] and RELIC_CLASS[rt] ~= class then res.unusable = res.unusable or rt end
                if text == "Two-Hand" and TWO_H_CLASSES[rt] and not TWO_H_CLASSES[rt][class] then res.unusable = res.unusable or ("two-handed " .. rt:lower()) end
                local wp = WEAPONS[class]
                if wp and WEAPON_TYPES[rt] and not wp[rt] then res.unusable = res.unusable or rt end
                if wp and wp[rt] and not res.unusable then
                    local sk = UntrainedWeapon(rt, text == "Two-Hand")
                    if sk then res.unusable = "train " .. sk end
                end
                local allowed = ARMOR_FROM[class]
                if allowed and (rt == "Cloth" or rt == "Leather" or rt == "Mail" or rt == "Plate" or rt == "Shield") then
                    local from = allowed[rt]
                    local lv = UnitLevel("player") or 1
                    if not from or lv < from then res.unusable = res.unusable or rt end
                end
            end
        end
    end
    -- a wand is worth its damage per second to a caster (melee weapon speed means nothing to one)
    if res.isWand and res.stats.DPS then res.stats.WDPS = res.stats.DPS end
    if not res.reqLevel then
        local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
        if fn then
            local ok, _, _, _, _, minLevel = pcall(fn, link)
            if ok and type(minLevel) == "number" and minLevel > 0 then res.reqLevel = minLevel end
        end
    end
    if ns.cache then ns.cache[link] = res end
    return res
end

function ns.Score(stats, w)
    local s = 0
    for k, v in pairs(stats) do
        local x = w[k]
        if x then s = s + v * x end
    end
    -- a pure healing item (healing power, no spell damage) has its Intellect, Spirit and mana regen
    -- budgeted for healing; a spec that doesn't heal gets only half credit for those stats
    if not w.HEAL and (stats.HEAL or 0) > 0 and (stats.SP or 0) == 0 then s = s * 0.5 end
    return s
end

-- Which inventory slot ids an item can go in.
local SLOTS = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_BODY = {}, INVTYPE_CHEST = { 5 },
    INVTYPE_ROBE = { 5 }, INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_WRIST = { 9 },
    INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 }, INVTYPE_CLOAK = { 15 },
    INVTYPE_WEAPON = { 16, 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 },
    INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_HOLDABLE = { 17 }, INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 },
    INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}
ns.SLOT_NAMES = { [1] = "Head", [2] = "Neck", [3] = "Shoulders", [5] = "Chest", [6] = "Waist", [7] = "Legs", [8] = "Feet",
    [9] = "Wrists", [10] = "Hands", [11] = "Ring", [12] = "Ring", [13] = "Trinket", [14] = "Trinket", [15] = "Back",
    [16] = "Main hand", [17] = "Off hand", [18] = "Ranged" }

-- A Hunter fights from range: weapon damage per second only matters on the ranged weapon,
-- the melee weapons are worth their stats.
local MELEE_LOC = { INVTYPE_WEAPON = true, INVTYPE_2HWEAPON = true, INVTYPE_WEAPONMAINHAND = true, INVTYPE_WEAPONOFFHAND = true }
local huntMelee = setmetatable({}, { __mode = "k" })
local RANGED_LOC = { INVTYPE_RANGED = true, INVTYPE_RANGEDRIGHT = true, INVTYPE_THROWN = true }
local lowRanged = setmetatable({}, { __mode = "k" })
local function WeightsBase(link, w)
    local loc = w.DPS and ns.EquipLoc(link) or ""
    local class = ns.Class()
    if class == "HUNTER" and MELEE_LOC[loc or ""] then
        local c = huntMelee[w]
        if not c then
            c = {}
            for k, v in pairs(w) do c[k] = v end
            c.DPS = w.DPS * 0.07
            huntMelee[w] = c
        end
        return c
    end
    -- Warriors, Rogues and the other melee classes only pull with a bow, gun or thrown weapon:
    -- its damage per second is not worth what a main hand weapon's is.
    if class ~= "HUNTER" and RANGED_LOC[loc or ""] then
        local c = lowRanged[w]
        if not c then
            c = {}
            for k, v in pairs(w) do c[k] = v end
            c.DPS = w.DPS * 0.07
            lowRanged[w] = c
        end
        return c
    end
    return w
end

-- How well you can use a weapon of this type: your trained skill against the most your level allows.
-- A dagger at skill 1 swings far worse than a sword at 58, so its damage is worth less until you train it up.
local SKILL_OF = { ["One-Handed Axes"] = "Axes", ["One-Handed Swords"] = "Swords", ["One-Handed Maces"] = "Maces" }
local skillNow, skillAt = nil, 0
local function WeaponSkills()
    local now = GetTime and GetTime() or 0
    if skillNow and now - skillAt < 5 then return skillNow end
    local saved = ns.db and ns.db.skills
    local found, any = {}, false
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, header, _, rank = GetSkillLineInfo(i)
            if name and not header and type(rank) == "number" then found[name] = rank any = true end
        end
    end
    if any and ns.db then
        ns.db.skills = ns.db.skills or {}
        for k, v in pairs(found) do ns.db.skills[k] = v end      -- remembered for when the skills window is collapsed
    end
    skillNow, skillAt = (any and found) or saved or {}, now
    return skillNow
end
local function WeaponFactor(link)
    local f = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if not f then return 1 end
    local ok, _, _, sub = pcall(f, link)
    if not ok or type(sub) ~= "string" then return 1 end
    local rank = WeaponSkills()[SKILL_OF[sub] or sub]
    if type(rank) ~= "number" then return 1 end
    local cap = math.max(5, 5 * (UnitLevel("player") or 1))
    return 0.5 + 0.5 * math.min(1, rank / cap)
end

-- Armor is worth far more at low level: the same points take a bigger bite out of the damage you take.
-- The tank weights were set for level 60 (damage taken falls by A / (A + 85 * level + 400)).
local tuned = setmetatable({}, { __mode = "k" })
local function WeightsFor(link, w)
    local base = WeightsBase(link, w)
    local lv = UnitLevel("player") or 60
    local armorK = 1
    if base.DODGE and base.ARMOR and lv < 60 then armorK = math.min(4, 5500 / (85 * lv + 400)) end
    local dpsK = 1
    local loc = base.DPS and ns.EquipLoc(link) or ""
    if base.DPS and (MELEE_LOC[loc] or RANGED_LOC[loc]) then dpsK = WeaponFactor(link) end
    if armorK == 1 and dpsK >= 0.995 then return base end
    local bucket = tuned[base]
    if not bucket then bucket = {} tuned[base] = bucket end
    local key = ("%d|%.2f"):format(lv, dpsK)
    local c = bucket[key]
    if not c then
        c = {}
        for k, v in pairs(base) do c[k] = v end
        if armorK ~= 1 then c.ARMOR = base.ARMOR * armorK end
        if dpsK ~= 1 then c.DPS = base.DPS * dpsK end
        bucket[key] = c
    end
    return c
end

local function ItemScore(link, w)
    local r = ns.ReadItem(link)
    return r and ns.Score(r.stats, WeightsFor(link, w)) or 0
end

-- levels at which a class learns to dual wield (Shaman need a talent, so they are left out)
local DUAL_WIELD_FROM = { ROGUE = 10, WARRIOR = 20, HUNTER = 20 }

-- Compare one item to what is worn. Returns a result table or nil if it is not gear.
-- { gain = percent (positive = better), slot = id, worn = link, score, wornScore, unusable, reqLevel, tooHigh }
function ns.Compare(link)
    local spec = ns.Spec()
    if not spec or not link then return nil end
    local equipLoc = ns.EquipLoc(link)
    local slots = equipLoc and SLOTS[equipLoc]
    if not slots or #slots == 0 then return nil end
    local info = ns.ReadItem(link)
    if not info then return nil end
    local w = spec.w
    local score = ns.Score(info.stats, WeightsFor(link, w))
    local level = UnitLevel("player") or 1
    local res = { score = score, unusable = info.unusable, reqLevel = info.reqLevel, equipLoc = equipLoc }
    if info.reqLevel and info.reqLevel > level then res.tooHigh = info.reqLevel end

    -- what it would replace: an empty slot first, otherwise the worn item that scores lowest
    local worn, wornScore, wornSlot
    if equipLoc == "INVTYPE_2HWEAPON" then
        local a, b = GetInventoryItemLink("player", 16), GetInventoryItemLink("player", 17)
        wornScore = (a and ItemScore(a, w) or 0) + (b and ItemScore(b, w) or 0)
        worn, wornSlot = a or b, 16
    else
        local bestKey
        if equipLoc == "INVTYPE_WEAPON" then
            -- a one-hander only goes in the off hand if you already dual wield
            local oh = GetInventoryItemLink("player", 17)
            local ohLoc = oh and ns.EquipLoc(oh)
            -- ...or you can dual wield and the off hand is still empty
            local mhl = GetInventoryItemLink("player", 16)
            local canDW = not oh and mhl and ns.EquipLoc(mhl) ~= "INVTYPE_2HWEAPON" and spec.role == "dps" and (DUAL_WIELD_FROM[ns.Class() or ""] or 99) <= level
            if ohLoc ~= "INVTYPE_WEAPON" and ohLoc ~= "INVTYPE_WEAPONOFFHAND" and not canDW then slots = { 16 } end
        end
        for _, s in ipairs(slots) do
            local l = GetInventoryItemLink("player", s)
            local key = l and ItemScore(l, w) or -1               -- -1: empty slot wins
            if bestKey == nil or key < bestKey then
                bestKey, worn, wornSlot = key, l, s
                wornScore = l and key or 0
            end
        end
    end
    wornScore = wornScore or 0
    -- a tank fights with a one-hander and a shield: a two-hander is never the suggestion, and while one is
    -- wielded the main hand and the shield slot both count as empty (a one-hander and a shield are what is missing)
    -- only the shield classes (Protection warrior and paladin); a bear druid cannot use a shield and tanks with a two-hander
    local arm = ns.Armor and ns.Armor[ns.Class() or ""]
    local shieldRole = (spec.role == "tank" or spec.role == "healer") and arm and arm.Shield and true or false   -- paladin and shaman healers use a one-hander and a shield too
    local tank = spec.role == "tank" and shieldRole
    local mhNow = GetInventoryItemLink("player", 16)
    local twoHandedNow = shieldRole and mhNow and ns.EquipLoc(mhNow) == "INVTYPE_2HWEAPON"
    if shieldRole and equipLoc == "INVTYPE_2HWEAPON" then res.unusable = res.unusable or (tank and "tanks" or "healers") .. " use a one-hander and a shield" end
    if tank and equipLoc == "INVTYPE_HOLDABLE" then res.unusable = res.unusable or "tanks use a shield" end
    if twoHandedNow and (equipLoc == "INVTYPE_WEAPON" or equipLoc == "INVTYPE_WEAPONMAINHAND") then
        worn, wornScore, wornSlot = nil, 0, 16
    end
    -- swapping out a piece of a set that is active loses the bonus that needed that piece
    if worn and equipLoc ~= "INVTYPE_2HWEAPON" then
        local wi = ns.ReadItem(worn)
        if wi and wi.setBonus and wi.setCount and wi.setName ~= info.setName then
            local lost = wi.setBonus[wi.setCount]
            if lost then wornScore = wornScore + ns.Score(lost, w) end
        end
    end
    res.worn, res.wornScore, res.slot = worn, wornScore, wornSlot or slots[1]
    if wornScore <= 0 then res.gain = score > 0 and 100 or 0
    else res.gain = (score - wornScore) / wornScore * 100 end
    -- an empty slot only counts when the item would actually give you something
    res.empty = (worn == nil) and score > 0
    if worn == nil and score <= 0 then res.gain = 0 end
    -- nothing goes in the off hand while a two-handed weapon is in the main hand
    if (equipLoc == "INVTYPE_SHIELD" or equipLoc == "INVTYPE_HOLDABLE" or equipLoc == "INVTYPE_WEAPONOFFHAND") then
        local mh = GetInventoryItemLink("player", 16)
        if mh and ns.EquipLoc(mh) == "INVTYPE_2HWEAPON" then
            if twoHandedNow and equipLoc == "INVTYPE_SHIELD" then worn, wornScore, res.worn, res.wornScore = nil, 0, nil, 0   -- tank: a shield is wanted
            else res.unusable = res.unusable or "two-handed weapon equipped" end
        end
    end
    for sl = 1, 19 do
        if GetInventoryItemLink("player", sl) == link then res.isWorn = true end
    end
    return res
end

-- Keeps only the best candidates per equipment slot (rings and trinkets: two, everything else: one).
-- The list must already be sorted best first.
local GROUP = { [12] = 11, [14] = 13 }
local function BestPerSlot(list)
    local out, count = {}, {}
    for _, e in ipairs(list) do
        local g = GROUP[e.slot] or e.slot
        count[g] = (count[g] or 0) + 1
        local cap = (g == 11 or g == 13) and 2 or 1
        if count[g] <= cap then out[#out + 1] = e end
    end
    return out
end

-- Everything in the bags that is better than what you wear, best first.
function ns.FindUpgrades()
    local out = {}
    for _, it in ipairs(ns.BagItems()) do
        local link = it.link
        local r = ns.Compare(link)
        if r and r.gain and r.gain >= (ns.db.minGain or 3) and not r.unusable then
            r.link, r.bag, r.bagSlot = link, it.bag, it.slot
            out[#out + 1] = r
        end
    end
    table.sort(out, function(a, b)
        local ah, bh = a.tooHigh and 1 or 0, b.tooHigh and 1 or 0
        if ah ~= bh then return ah < bh end
        return a.gain > b.gain
    end)
    return BestPerSlot(out)
end

ns.BestPerSlot = BestPerSlot

-- Every equipped item with a score, for the "Equipped" view.
function ns.EquippedScores()
    local spec = ns.Spec()
    local out = {}
    if not spec then return out end
    for s = 1, 18 do
        if s ~= 4 then
            local l = GetInventoryItemLink("player", s)
            out[#out + 1] = { slot = s, link = l, score = l and ItemScore(l, spec.w) or 0 }
        end
    end
    return out
end

-- Extra candidates read from Profiteer's saved data (if it is installed): gear your characters can
-- craft, and gear sitting in your other characters' bags and bank. Works for every class.
local function ShortChar(k) return (tostring(k):match("^[^-]+")) or tostring(k) end

local function DynamicSources(have, known)
    local out = {}
    local db = _G.ProfiteerDB
    if type(db) ~= "table" then return out end
    local me = UnitName and UnitName("player")
    local names = type(db.names) == "table" and db.names or {}
    local function nameOf(id, fallback)
        return names[id] or fallback or (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or ("item " .. id)
    end
    -- Soulbound / bind-on-pickup gear cannot be handed from one character to another
    local function tradable(id)
        local r = ns.ReadItem and ns.ReadItem("item:" .. id)
        return r ~= nil and r.bind ~= "bop"
    end
    local function add(id, name, how, where, needsTrade)
        if type(id) ~= "number" or have[id] or known[id] then return end
        if not ns.EquipLoc("item:" .. id) then return end        -- not wearable
        if needsTrade and not tradable(id) then return end
        known[id] = true
        out[#out + 1] = { id, nameOf(id, name), 1, how, where, "" }
    end
    -- bags and bank of your other characters
    for ck, inv in pairs(type(db.inventory) == "table" and db.inventory or {}) do
        if ShortChar(ck) ~= me and type(inv) == "table" then
            for _, where in ipairs({ "bags", "bank" }) do
                for id in pairs(type(inv[where]) == "table" and inv[where] or {}) do
                    add(id, nil, "alt", ("in %s's %s"):format(ShortChar(ck), where), true)
                end
            end
        end
    end
    -- gear your characters know how to make
    for ck, profs in pairs(type(db.recipes) == "table" and db.recipes or {}) do
        for prof, recs in pairs(type(profs) == "table" and profs or {}) do
            for _, r in ipairs(type(recs) == "table" and recs or {}) do
                local mine = ShortChar(ck) == me
                add(r.id, r.name, "crafted", mine and ("%s - you know the recipe"):format(prof)
                    or ("%s - %s knows the recipe"):format(prof, ShortChar(ck)), not mine)
            end
        end
    end
    return out
end

-- Known gear that would beat what you wear, best first: the built-in lists for the cloth casters,
-- plus gear your other characters hold or can craft (any class).
-- Returns list, pending (items whose data the game has not sent yet), checked.
-- A bind-on-pickup craft is only yours if your character has the profession itself.
local function CraftOnlyByOthers(link, where)
    local info = ns.ReadItem(link)
    if not (info and info.bind == "bop") then return false end
    if where:find("you know", 1, true) then return false end
    local prof = where:match("^(%a+)")
    return prof ~= nil and HasSkill(prof, 1) == false
end

function ns.FindSources()
    local out, pending, checked = {}, 0, 0
    local group = ns.SourceClasses and ns.SourceClasses[ns.Class() or ""]
    local static = group and ns.Sources and ns.Sources[group] or {}
    local level = UnitLevel("player") or 1
    local have, known = {}, {}
    for _, it in ipairs(ns.BagItems()) do
        local id = tonumber((it.link or ""):match("item:(%d+)"))
        if id then have[id] = true end
    end
    for sl = 1, 19 do
        local l = GetInventoryItemLink("player", sl)
        local id = l and tonumber(l:match("item:(%d+)"))
        if id then have[id] = true end
    end
    local list = {}
    for _, e in ipairs(static) do known[e[1]] = true list[#list + 1] = e end
    for _, e in ipairs(DynamicSources(have, known)) do list[#list + 1] = e end
    -- quests, vendors and dungeon bosses for every class, from the quest database
    if ns.QuestSources then
        if not ns.QIndex.ready then
            ns.QuestIndexStart()
            pending = pending + 1                 -- still reading the database; the tab refreshes when done
        end
        for _, e in ipairs(ns.QuestSources(level, have, known)) do list[#list + 1] = e end
    end
    for _, e in ipairs(list) do
        local id, name, req, how, where, note = e[1], e[2], e[3], e[4], e[5], e[6]
        if not have[id] and req <= level and ns.SourceOn(ns.SourceKind({ id = id, how = how, where = where })) then
            checked = checked + 1
            local link = "item:" .. id
            local r = ns.Compare(link)
            if r == nil then
                if ns.EquipLoc(link) then pending = pending + 1 end
            elseif (r.empty or (r.gain and r.gain >= (ns.db.minGain or 3))) and not r.unusable and not r.tooHigh
                and not (how == "crafted" and CraftOnlyByOthers(link, where)) then
                r.link, r.name, r.req, r.how, r.where, r.note, r.id = link, name, req, how, where, note, id
                if r.empty then r.gain = 1000 + (r.score or 0) end
                out[#out + 1] = r
            end
        end
    end
    table.sort(out, function(a, b)
        local ah, bh = a.note ~= "" and 1 or 0, b.note ~= "" and 1 or 0     -- faction-unsure quests last
        if ah ~= bh then return ah < bh end
        return a.gain > b.gain
    end)
    return BestPerSlot(out), pending, checked
end

function ns.SlotsFor(loc)
    local t = SLOTS[loc]
    return t and #t > 0 and t or nil
end
